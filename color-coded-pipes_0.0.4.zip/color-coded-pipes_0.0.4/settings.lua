
data:extend{
    {
        type = "string-setting",
        name = "color-coded-pipes-color-mode",
        setting_type = "startup",
        default_value = "colorized",
        allowed_values = { "weathered", "colorized" },
    },
    {
        type = "bool-setting",
        name = "color-coded-main-menu-simulations",
        setting_type = "startup",
        default_value = true,
    }
}
